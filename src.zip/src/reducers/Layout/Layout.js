import { createStyles } from "@mui/material";
import { getcategories } from "../../api/Layout/LayoutApi";

let Layout = createStyles({
  name: "Layout",
  initialState: {},
  reducers: {},
});
export default Layout.reducers;
