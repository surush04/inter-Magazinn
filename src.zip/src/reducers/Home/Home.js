import { getcategories, getproducts } from "../../api/Home/HomeApi";
import { createSlice } from "@reduxjs/toolkit";

let Home = createSlice({
  name: "Home",
  initialState: {
    data: [],
    data2: [],
    loading: false,
    subData: [],
  },
  reducers: {
    setSubData: (state, value) => {
      state.subData = value.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getproducts.pending, (state, action) => {
      state.loading = true;
    });
    builder.addCase(getproducts.fulfilled, (state, action) => {
      state.loading = false;
      state.data = action.payload;
    });
    builder.addCase(getproducts.rejected, (state, action) => {
      state.loading.false;
    });
    // get-categories
    builder.addCase(getcategories.pending, (state, action) => {
      state.loading = true;
    });
    builder.addCase(getcategories.fulfilled, (state, action) => {
      state.loading = false;
      state.data2 = action.payload;
      console.log(action.payload);
    });
    builder.addCase(getcategories.rejected, (state, action) => {
      state.loading.false;
    });
  },
});

export default Home.reducer;
export const { setSubData } = Home.actions;
