import React from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";

const Basket = () => {
  return (
    <div>
      <h1 className="text-[40px] ml-[10%] font-semibold">Корзина</h1>
      <div className="flex justify-center items-center flex-col py-[30px]">
        <div className="flex flex-col items-center justify-center ">
          <Link to={"/"}>
            <img
              src="src/img/logotip.jpg"
              alt=""
              className="w-[300px] rounded-[50px]"
            />
          </Link>
          <h1 className="text-[green] text-[50px]  relative bottom-16 font-serif">
            Surush
          </h1>
        </div>
        <h1 className="text-[40px] font-semibold">Внутри пока нет товаров</h1>
        <p className="text-[22px] clear-start m-[20px]">
          Перейдите в раздел с товарами, чтобы оставить заявку
        </p>
        <Button variant="contained" color="success">
          Success
        </Button>
      </div>
    </div>
  );
};

export default Basket;
