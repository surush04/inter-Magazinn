import React from "react";

const Catalog = () => {
  return (
    <div>
      <h1 className="text-[40px] ml-[10%] font-semibold">Каталог товаров</h1>
    </div>
  );
};

export default Catalog;
